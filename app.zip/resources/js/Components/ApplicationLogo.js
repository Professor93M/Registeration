import React from "react";

export default function ApplicationLogo({ className }) {
    // return <span>SAUC</span>;
    return <img className="h-36 w-36" src="./images/logo.png"></img>
}
