<?php

use App\Http\Controllers\StudentsController;
use Illuminate\Support\Facades\Route;

Route::get('/', [StudentsController::class, 'home'])->name('dashboard');

Route::get('stages', [StudentsController::class, 'stages'])->name('stages');

require __DIR__.'/auth.php';
